﻿namespace JokesWebApp.Models
{
    public class Joke
    {

        public int Id { get; set; }

        public string JokeQuestion { get; set; }

        public string JokeAnswer { get; set; }

       //Make another property that returns list (Manual List)

        //Bind to create/delete


        public Joke()
        {
            
        }

    }
}
